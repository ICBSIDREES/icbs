ICBS Academy — Portable iPhone Export
=====================================

Entry file:
  index.html

This export is based on the saved ICBS_ACADEMY_MASTER_V2_MANUAL_SEQUENCE_iPHONE.html master file.
The HTML contains the site's CSS, JavaScript, and lesson/manual images inline as data URLs, so there are no required local CSS/JS/image folders.

iPhone use:
1. Upload index.html (or the ZIP) to another ChatGPT account.
2. If opening the HTML directly on iPhone, use a browser/file app that can open local HTML files.
3. The Arabic/Kurdish language toggle and the lesson navigation are contained in index.html.

Audio note:
The current master HTML references four public MP3 URLs hosted on Google Cloud Storage. Those audio files could not be copied as local binaries in this export environment, so the HTML keeps the original public URLs. Internet access is required for those audio buttons.

Security:
No explicit OpenAI API key, bearer token, GitHub token, or secret-key field was found in the master HTML. Base64 image data contains incidental text that can resemble key prefixes; these are embedded image data, not detected credential fields.

This package does not include private Replit/OpenAI secrets.
